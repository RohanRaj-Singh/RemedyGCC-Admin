# Tasks
- Build dashboard
- Tenant CRUD UI
- Scanner builder UI
- Logs UI
