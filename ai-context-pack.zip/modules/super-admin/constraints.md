# Constraints
- One scanner per tenant
- No direct DB access from frontend
