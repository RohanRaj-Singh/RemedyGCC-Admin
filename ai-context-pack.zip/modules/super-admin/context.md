# Super Admin Context
Purpose: Control platform

Modules:
- Dashboard
- Tenants
- Scanners
- Logs
